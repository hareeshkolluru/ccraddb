/**
 * A store used for displaying reviews.
 */
Ext.define('Books.store.Reviews', {
    extend: 'Ext.data.Store',
    model: 'Books.model.Review'
});